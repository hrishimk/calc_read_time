=== Calc read time ===
Contributors: avastava
Donate link: http://jijnasu.in/
Tags: read time, read time calculator
Requires at least: 3.0.1
Tested up to: 4.6.1
Stable tag: 4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Calc read time shows estimated read time near titles on post pages. It gives the reader a rough idea of the time he/she is going to spend reading the article.

== Description ==



== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress

== Frequently Asked Questions ==


== Screenshots ==

1. The plugin showing read time in a post.

== Changelog ==

= 1.0 =
First release.

== Upgrade Notice ==


== Arbitrary section ==


== A brief Markdown Example ==

`<?php code(); // goes in backticks ?>`
